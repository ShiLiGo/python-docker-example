# ************************************************************
# Sequel Ace SQL dump
# 版本号： 20067
#
# https://sequel-ace.com/
# https://github.com/Sequel-Ace/Sequel-Ace
#
# 主机: 192.168.1.15 (MySQL 5.6.28-cdb2016-log)
# 数据库: duole
# 生成时间: 2024-12-06 06:27:33 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE='NO_AUTO_VALUE_ON_ZERO', SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# 转储表 address
# ------------------------------------------------------------

CREATE TABLE `address` (
  `userid` bigint(20) NOT NULL,
  `realname` varchar(20) DEFAULT NULL,
  `telnum` varchar(20) DEFAULT NULL,
  `postalcode` varchar(10) DEFAULT NULL,
  `address` varchar(128) DEFAULT NULL,
  `freshtime` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 ajpurchase
# ------------------------------------------------------------

CREATE TABLE `ajpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `orderid` varchar(35) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `gameid` int(11) DEFAULT '0',
  `roleid` varchar(30) DEFAULT NULL,
  `serverid` int(11) DEFAULT '0',
  `paytype` varchar(10) DEFAULT NULL,
  `amount` int(11) DEFAULT '0',
  `paytime` int(11) DEFAULT '0',
  `attach` varchar(64) DEFAULT NULL,
  `sign` varchar(64) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 alipaypurchase
# ------------------------------------------------------------

CREATE TABLE `alipaypurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `out_trade_no` varchar(64) DEFAULT NULL,
  `seller_email` varchar(100) DEFAULT NULL,
  `subject` varchar(64) DEFAULT NULL,
  `total_fee` float DEFAULT NULL,
  `buyer_email` varchar(100) DEFAULT NULL,
  `trade_status` varchar(64) DEFAULT NULL,
  `trade_no` varchar(64) DEFAULT NULL,
  `seller_id` varchar(30) DEFAULT NULL,
  `notify_id` varchar(64) DEFAULT NULL,
  `gmt_create` varchar(24) DEFAULT NULL,
  `body` varchar(64) DEFAULT NULL,
  `buyer_id` varchar(30) DEFAULT NULL,
  `gmt_payment` varchar(24) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 alipaypurchasev2
# ------------------------------------------------------------

CREATE TABLE `alipaypurchasev2` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `out_trade_no` varchar(64) DEFAULT NULL,
  `notify_time` varchar(32) DEFAULT NULL,
  `notify_type` varchar(64) DEFAULT NULL,
  `notify_id` varchar(128) DEFAULT NULL,
  `app_id` varchar(32) DEFAULT NULL,
  `charset` varchar(10) DEFAULT NULL,
  `version` varchar(3) DEFAULT NULL,
  `trade_no` varchar(64) DEFAULT NULL,
  `out_biz_no` varchar(64) DEFAULT NULL,
  `buyer_id` varchar(16) DEFAULT NULL,
  `buyer_logon_id` varchar(100) DEFAULT NULL,
  `seller_id` varchar(30) DEFAULT NULL,
  `seller_email` varchar(100) DEFAULT NULL,
  `trade_status` varchar(32) DEFAULT NULL,
  `total_amount` varchar(32) DEFAULT NULL,
  `receipt_amount` varchar(32) DEFAULT NULL,
  `invoice_amount` varchar(32) DEFAULT NULL,
  `buyer_pay_amount` varchar(32) DEFAULT NULL,
  `point_amount` varchar(32) DEFAULT NULL,
  `refund_fee` varchar(32) DEFAULT NULL,
  `subject` varchar(256) DEFAULT NULL,
  `body` varchar(400) DEFAULT NULL,
  `gmt_create` varchar(32) DEFAULT NULL,
  `gmt_payment` varchar(32) DEFAULT NULL,
  `gmt_refund` varchar(32) DEFAULT NULL,
  `gmt_close` varchar(32) DEFAULT NULL,
  `fund_bill_list` varchar(512) DEFAULT NULL,
  `passback_params` varchar(512) DEFAULT NULL,
  `voucher_detail_list` text,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 alipaytransfer
# ------------------------------------------------------------

CREATE TABLE `alipaytransfer` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `outbizno` varchar(256) DEFAULT '',
  `amount` varchar(20) DEFAULT '0',
  `payeeaccount` varchar(128) DEFAULT '',
  `payeerealname` varchar(128) DEFAULT '',
  `code` int(11) DEFAULT '0',
  `msg` varchar(128) DEFAULT '',
  `subcode` varchar(128) DEFAULT '',
  `submsg` varchar(128) DEFAULT '',
  `sign` varchar(1024) DEFAULT '',
  `orderid` varchar(256) DEFAULT '',
  `paydate` varchar(128) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `KEY_outbizno` (`outbizno`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 alipaytransferv2
# ------------------------------------------------------------

CREATE TABLE `alipaytransferv2` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `outbizno` varchar(64) DEFAULT NULL,
  `amount` varchar(16) DEFAULT NULL,
  `payeeaccount` varchar(128) DEFAULT NULL,
  `payeerealname` varchar(128) DEFAULT NULL,
  `code` varchar(128) DEFAULT NULL,
  `msg` varchar(128) DEFAULT NULL,
  `subcode` varchar(128) DEFAULT NULL,
  `submsg` varchar(128) DEFAULT NULL,
  `orderid` varchar(32) DEFAULT NULL,
  `payfundorderid` varchar(32) DEFAULT NULL,
  `status` varchar(32) DEFAULT NULL,
  `transdate` varchar(30) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `KEY_outbizno` (`outbizno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 allpaytypeinfo
# ------------------------------------------------------------

CREATE TABLE `allpaytypeinfo` (
  `type` int(11) NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 appleuser
# ------------------------------------------------------------

CREATE TABLE `appleuser` (
  `refid` varchar(240) NOT NULL,
  `unionid` varchar(240) NOT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`refid`),
  UNIQUE KEY `unionid` (`unionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 appleuserbind
# ------------------------------------------------------------

CREATE TABLE `appleuserbind` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sub` varchar(240) NOT NULL,
  `teamid` varchar(256) NOT NULL,
  `fromsub` varchar(256) NOT NULL,
  `fromteamid` varchar(256) NOT NULL,
  `fromgameid` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sub` (`sub`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 appleusertransfer
# ------------------------------------------------------------

CREATE TABLE `appleusertransfer` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `transfersub` varchar(240) NOT NULL,
  `fromsub` varchar(240) NOT NULL,
  `fromteamid` varchar(256) NOT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transfersub` (`transfersub`),
  KEY `fromsub` (`fromsub`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 appleusertransfererrorlog
# ------------------------------------------------------------

CREATE TABLE `appleusertransfererrorlog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `claims` varchar(1024) NOT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 appstorenotifylog
# ------------------------------------------------------------

CREATE TABLE `appstorenotifylog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `url` varchar(1024) NOT NULL,
  `method` varchar(8) NOT NULL,
  `body` text,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 appstorenotifyrecord
# ------------------------------------------------------------

CREATE TABLE `appstorenotifyrecord` (
  `orderid` varchar(128) NOT NULL DEFAULT '',
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`orderid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 appstorepurchase
# ------------------------------------------------------------

CREATE TABLE `appstorepurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `orderid` varchar(128) DEFAULT NULL,
  `sandbox` int(11) DEFAULT NULL,
  `productid` varchar(64) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `bid` varchar(64) DEFAULT NULL,
  `bvrs` varchar(64) DEFAULT NULL,
  `transactionid` varchar(64) DEFAULT NULL,
  `receiptinfo` text NOT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 appstorepurchaseverifiedrecord
# ------------------------------------------------------------

CREATE TABLE `appstorepurchaseverifiedrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `verifyid` bigint(20) NOT NULL,
  `receipt` text NOT NULL,
  `receiptinfo` text NOT NULL,
  `sandbox` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 appstorepurchaseverifyinginfo
# ------------------------------------------------------------

CREATE TABLE `appstorepurchaseverifyinginfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `transactionid` varchar(64) DEFAULT NULL,
  `productid` varchar(64) DEFAULT NULL,
  `orderid` varchar(128) DEFAULT NULL,
  `receipt` text NOT NULL,
  `verifycount` int(11) DEFAULT NULL,
  `verifytime` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 autochargelog
# ------------------------------------------------------------

CREATE TABLE `autochargelog` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `ServerOrderID` varchar(512) DEFAULT NULL,
  `userID` bigint(20) NOT NULL,
  `status` int(4) DEFAULT NULL,
  `GoodsID` varchar(512) DEFAULT NULL,
  `ClientOrderID` varchar(512) DEFAULT NULL,
  `req_MobileNum` varchar(512) DEFAULT NULL,
  `ack_MobileNum` varchar(512) DEFAULT NULL,
  `ack_tf` int(4) DEFAULT NULL,
  `ack_fm` int(4) DEFAULT NULL,
  `ack_dm` double(20,10) DEFAULT NULL,
  `req_pr` int(4) DEFAULT NULL,
  `req_nb` int(4) DEFAULT NULL,
  `req_fm` int(4) DEFAULT NULL,
  `gameid` int(4) DEFAULT NULL,
  `gameorderid` varchar(512) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `beizhu` varchar(512) DEFAULT NULL,
  `xmlinfo` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 avatardetectinfo
# ------------------------------------------------------------

CREATE TABLE `avatardetectinfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `avatar` varchar(128) DEFAULT NULL,
  `tag` int(11) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQUE_avatar` (`avatar`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 avatardetectrecord
# ------------------------------------------------------------

CREATE TABLE `avatardetectrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `avatar` varchar(128) DEFAULT NULL,
  `response` text,
  `gameid` int(4) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `KEY_userid` (`userid`),
  KEY `KEY_avatar` (`avatar`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 avatarinfo
# ------------------------------------------------------------

CREATE TABLE `avatarinfo` (
  `name` varchar(64) NOT NULL,
  `type` int(1) NOT NULL DEFAULT '1',
  `uri` varchar(256) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 avatarporndetectinfo
# ------------------------------------------------------------

CREATE TABLE `avatarporndetectinfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `avatar` varchar(128) DEFAULT NULL,
  `avatarurl` varchar(128) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQUE_userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 avatarporndetectrecord
# ------------------------------------------------------------

CREATE TABLE `avatarporndetectrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `avatar` varchar(128) DEFAULT NULL,
  `result` int(11) DEFAULT NULL,
  `confidence` decimal(6,3) DEFAULT NULL,
  `hotscore` decimal(6,3) DEFAULT NULL,
  `pornscore` decimal(6,3) DEFAULT NULL,
  `normalscore` decimal(6,3) DEFAULT NULL,
  `forbidstatus` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQUE_avatar` (`avatar`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 avatarpornuploadrecord
# ------------------------------------------------------------

CREATE TABLE `avatarpornuploadrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `avatar` varchar(128) DEFAULT NULL,
  `confidence` decimal(6,3) DEFAULT NULL,
  `gameid` int(4) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 avatartypeinfo
# ------------------------------------------------------------

CREATE TABLE `avatartypeinfo` (
  `type` int(11) NOT NULL,
  `desc` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 baiduminipurchase
# ------------------------------------------------------------

CREATE TABLE `baiduminipurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `tporderid` varchar(64) NOT NULL,
  `bduserid` int(11) NOT NULL,
  `bdorderid` varchar(64) NOT NULL,
  `unitprice` int(11) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `totalmoney` int(11) DEFAULT NULL,
  `paymoney` int(11) DEFAULT NULL,
  `promomoney` int(11) DEFAULT NULL,
  `hbmoney` int(11) DEFAULT NULL,
  `hbbalancemoney` int(11) DEFAULT NULL,
  `giftcardmoney` int(11) DEFAULT NULL,
  `dealid` int(11) DEFAULT NULL,
  `paytime` int(11) DEFAULT NULL,
  `promodetail` int(11) DEFAULT NULL,
  `paytype` int(11) DEFAULT NULL,
  `partnerid` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `returndata` int(11) DEFAULT NULL,
  `rsasign` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 baidupurchase
# ------------------------------------------------------------

CREATE TABLE `baidupurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `appid` int(11) NOT NULL,
  `orderid` varchar(64) NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `unit` varchar(32) DEFAULT NULL,
  `jfd` varchar(64) DEFAULT NULL,
  `status` varchar(32) DEFAULT NULL,
  `paychannel` varchar(32) DEFAULT NULL,
  `phone` varchar(32) DEFAULT NULL,
  `channel` varchar(32) DEFAULT NULL,
  `fromsdk` varchar(32) DEFAULT NULL,
  `sign` varchar(128) DEFAULT NULL,
  `extchannel` varchar(32) DEFAULT NULL,
  `cpdefinepart` varchar(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 baiduuser
# ------------------------------------------------------------

CREATE TABLE `baiduuser` (
  `unionid` varchar(240) NOT NULL,
  `refid` varchar(240) DEFAULT NULL,
  `openid` varchar(240) NOT NULL,
  `nickname` varchar(240) DEFAULT NULL,
  `gender` int(4) DEFAULT '0',
  `headimgurl` varchar(1024) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`unionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 bh_year_report
# ------------------------------------------------------------

CREATE TABLE `bh_year_report` (
  `userid` bigint(20) NOT NULL,
  `game` int(10) DEFAULT '0',
  `win` int(10) DEFAULT '0',
  `emperor` int(10) DEFAULT '0',
  `emperor_win` int(10) DEFAULT '0',
  `guard` int(10) DEFAULT '0',
  `guard_win` int(10) DEFAULT '0',
  `farmer` int(10) DEFAULT '0',
  `farmer_win` int(10) DEFAULT '0',
  `bankrupt` int(10) DEFAULT '0',
  `time` bigint(20) DEFAULT '0',
  `total_win_money` bigint(20) DEFAULT '0',
  `total_win_money_one` bigint(20) DEFAULT '0',
  `total_win_money_two` bigint(20) DEFAULT '0',
  `total_win_money_three` bigint(20) DEFAULT '0',
  `total_win_money_four` bigint(20) DEFAULT '0',
  `max_win_money` bigint(10) DEFAULT '0',
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 bilibilipurchase
# ------------------------------------------------------------

CREATE TABLE `bilibilipurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `orderid` varchar(128) DEFAULT NULL,
  `order_no` varchar(128) DEFAULT NULL,
  `out_trade_no` varchar(128) DEFAULT NULL,
  `uid` bigint(20) DEFAULT NULL,
  `username` varchar(64) DEFAULT NULL,
  `role` varchar(64) DEFAULT NULL,
  `money` varchar(32) DEFAULT NULL,
  `pay_money` varchar(32) DEFAULT NULL,
  `game_money` varchar(32) DEFAULT NULL,
  `merchant_id` varchar(32) DEFAULT NULL,
  `game_id` varchar(32) DEFAULT NULL,
  `zone_id` varchar(32) DEFAULT NULL,
  `product_name` varchar(64) DEFAULT NULL,
  `product_desc` varchar(64) DEFAULT NULL,
  `pay_time` varchar(64) DEFAULT NULL,
  `client_ip` varchar(64) DEFAULT NULL,
  `extension_info` varchar(256) DEFAULT NULL,
  `order_status` int(11) DEFAULT NULL,
  `product_id` varchar(64) DEFAULT NULL,
  `is_sandbox` int(11) DEFAULT NULL,
  `sign` varchar(256) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 bilibiliuser
# ------------------------------------------------------------

CREATE TABLE `bilibiliuser` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `refid` varchar(240) NOT NULL,
  `openid` varchar(256) NOT NULL,
  `uname` varchar(256) NOT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `refid` (`refid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 blacklist
# ------------------------------------------------------------

CREATE TABLE `blacklist` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` int(4) DEFAULT NULL,
  `content` varchar(120) DEFAULT NULL,
  `permission` varchar(512) DEFAULT '{"game": [0], "scene": "all"}',
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `content` (`content`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 bytedanceuser
# ------------------------------------------------------------

CREATE TABLE `bytedanceuser` (
  `refid` varchar(240) NOT NULL DEFAULT '',
  `unionid` varchar(240) NOT NULL,
  `nickname` varchar(240) DEFAULT NULL,
  `gender` int(4) DEFAULT NULL,
  `province` varchar(240) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `avatarurl` varchar(1024) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`refid`),
  UNIQUE KEY `unionid` (`unionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 bytedanceuserbind
# ------------------------------------------------------------

CREATE TABLE `bytedanceuserbind` (
  `openid` varchar(128) NOT NULL DEFAULT '',
  `appid` varchar(64) NOT NULL DEFAULT '',
  `unionid` varchar(128) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`openid`,`appid`),
  KEY `KEY_unionid` (`unionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 callbacklog
# ------------------------------------------------------------

CREATE TABLE `callbacklog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `url` varchar(128) NOT NULL,
  `method` varchar(8) NOT NULL,
  `body` varchar(256) DEFAULT NULL,
  `type` varchar(12) DEFAULT NULL,
  `userid` int(20) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 changbapurchase
# ------------------------------------------------------------

CREATE TABLE `changbapurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `orderid` varchar(50) DEFAULT NULL,
  `transtype` int(11) DEFAULT '0',
  `transid` varchar(50) DEFAULT NULL,
  `appid` varchar(20) DEFAULT NULL,
  `waresid` int(11) DEFAULT '0',
  `feetype` int(11) DEFAULT '0',
  `money` float DEFAULT '0',
  `currency` varchar(10) DEFAULT NULL,
  `result` int(11) DEFAULT '0',
  `transtime` varchar(20) DEFAULT NULL,
  `cpprivate` varchar(20) DEFAULT NULL,
  `paytype` int(11) DEFAULT '0',
  `sign` varchar(2048) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 coinChange
# ------------------------------------------------------------

CREATE TABLE `coinChange` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(256) NOT NULL,
  `productid` varchar(20) DEFAULT NULL,
  `num` int(4) DEFAULT NULL,
  `userid` bigint(20) DEFAULT NULL,
  `coinchg` int(11) DEFAULT NULL,
  `coin` bigint(20) DEFAULT NULL,
  `gameid` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 deactivateinfo
# ------------------------------------------------------------

CREATE TABLE `deactivateinfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `token` varchar(128) DEFAULT NULL,
  `url` varchar(256) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 delivernotifiedrecord
# ------------------------------------------------------------

CREATE TABLE `delivernotifiedrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(128) DEFAULT NULL,
  `notifydata` text,
  `responsedata` text,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 delivernotifyinginfo
# ------------------------------------------------------------

CREATE TABLE `delivernotifyinginfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(128) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `notifycount` int(11) DEFAULT NULL,
  `notifytime` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderid` (`orderid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 douyinminipurchase
# ------------------------------------------------------------

CREATE TABLE `douyinminipurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `cp_orderno` varchar(64) DEFAULT NULL,
  `appid` varchar(64) DEFAULT NULL,
  `amount_cent` int(11) DEFAULT NULL,
  `order_no_channel` varchar(128) DEFAULT NULL,
  `amount_coin` int(11) DEFAULT NULL,
  `cp_extra` varchar(128) DEFAULT NULL,
  `nonce` varchar(32) DEFAULT NULL,
  `echostr` varchar(32) DEFAULT NULL,
  `timestamp` varchar(32) DEFAULT NULL,
  `signature` varchar(128) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 douyinpurchase
# ------------------------------------------------------------

CREATE TABLE `douyinpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `cporderid` varchar(256) DEFAULT NULL,
  `appid` varchar(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `sdkopenid` varchar(128) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `actualamount` int(11) DEFAULT NULL,
  `couponamount` int(11) DEFAULT NULL,
  `productid` varchar(64) DEFAULT NULL,
  `productname` varchar(128) DEFAULT NULL,
  `extrainfo` varchar(256) DEFAULT NULL,
  `orderextrainfo` varchar(256) DEFAULT NULL,
  `douyincreatetime` int(20) DEFAULT NULL,
  `paytime` int(20) DEFAULT NULL,
  `logid` varchar(128) DEFAULT NULL,
  `sign` varchar(516) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 douyinuser
# ------------------------------------------------------------

CREATE TABLE `douyinuser` (
  `refid` varchar(240) NOT NULL DEFAULT '',
  `sdkopenid` int(64) NOT NULL,
  `agetype` int(32) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`refid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 duolepointalipaypurchase
# ------------------------------------------------------------

CREATE TABLE `duolepointalipaypurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `out_trade_no` varchar(64) DEFAULT NULL,
  `seller_email` varchar(100) DEFAULT NULL,
  `subject` varchar(64) DEFAULT NULL,
  `total_fee` float DEFAULT NULL,
  `buyer_email` varchar(100) DEFAULT NULL,
  `trade_status` varchar(64) DEFAULT NULL,
  `trade_no` varchar(64) DEFAULT NULL,
  `seller_id` varchar(30) DEFAULT NULL,
  `notify_id` varchar(64) DEFAULT NULL,
  `gmt_create` varchar(24) DEFAULT NULL,
  `body` varchar(64) DEFAULT NULL,
  `buyer_id` varchar(30) DEFAULT NULL,
  `gmt_payment` varchar(24) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 duolepointexchangecode
# ------------------------------------------------------------

CREATE TABLE `duolepointexchangecode` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cardid` varchar(64) NOT NULL,
  `code` varchar(64) NOT NULL,
  `status` int(10) NOT NULL,
  `cost` int(11) NOT NULL,
  `freshtime` datetime NOT NULL,
  `expiretime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cardid` (`cardid`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 duolepointinfo
# ------------------------------------------------------------

CREATE TABLE `duolepointinfo` (
  `userid` bigint(20) NOT NULL,
  `duolepoint` bigint(20) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 duolepointinfochange
# ------------------------------------------------------------

CREATE TABLE `duolepointinfochange` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `balance` bigint(20) DEFAULT NULL,
  `remark` varchar(256) NOT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 duolepointpaycallbacklog
# ------------------------------------------------------------

CREATE TABLE `duolepointpaycallbacklog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `url` varchar(1024) DEFAULT NULL,
  `method` varchar(8) NOT NULL,
  `body` varchar(4096) DEFAULT NULL,
  `userid` int(20) NOT NULL,
  `type` varchar(12) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 duolepointpayrecord
# ------------------------------------------------------------

CREATE TABLE `duolepointpayrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `orderid` varchar(256) NOT NULL,
  `outtradeorderid` varchar(256) NOT NULL,
  `productdesc` varchar(256) NOT NULL,
  `totalfee` int(11) DEFAULT NULL,
  `extradata` varchar(256) NOT NULL,
  `notifyurl` varchar(256) NOT NULL,
  `sign` varchar(512) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `beizhu` varchar(256) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `freshtime` datetime DEFAULT NULL,
  `notifystatus` int(4) DEFAULT '0',
  `lastnotifytime` datetime DEFAULT NULL,
  `notifytimes` int(4) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `index_orderid` (`orderid`(255)),
  KEY `index_outtradeorderid` (`outtradeorderid`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 duolepointtotalpurchase
# ------------------------------------------------------------

CREATE TABLE `duolepointtotalpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `orderid` varchar(256) NOT NULL,
  `duolepoint` int(11) DEFAULT NULL,
  `totalfee` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `beizhu` varchar(256) DEFAULT NULL,
  `method` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `AK_KEY_userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 egamepurchase
# ------------------------------------------------------------

CREATE TABLE `egamepurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `cp_order_id` varchar(64) NOT NULL,
  `correlator` varchar(64) NOT NULL,
  `result_code` varchar(20) DEFAULT NULL,
  `fee` float DEFAULT NULL,
  `pay_type` varchar(32) DEFAULT NULL,
  `version` varchar(32) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 emailbind
# ------------------------------------------------------------

CREATE TABLE `emailbind` (
  `userid` bigint(20) NOT NULL,
  `email` varchar(64) NOT NULL,
  PRIMARY KEY (`userid`),
  KEY `AK_KEY_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 emailbindbak
# ------------------------------------------------------------

CREATE TABLE `emailbindbak` (
  `userid` bigint(20) NOT NULL,
  `email` varchar(64) NOT NULL,
  `status` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`),
  KEY `AK_KEY_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 errorpurchaseinfo
# ------------------------------------------------------------

CREATE TABLE `errorpurchaseinfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `thirdpartyorderid` varchar(128) NOT NULL,
  `orderid` varchar(128) DEFAULT NULL,
  `formatbody` text,
  `body` text,
  `method` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `thirdpartyorderid` (`thirdpartyorderid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 gameidinfo
# ------------------------------------------------------------

CREATE TABLE `gameidinfo` (
  `id` int(11) NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 gj_year_report
# ------------------------------------------------------------

CREATE TABLE `gj_year_report` (
  `userid` bigint(20) NOT NULL,
  `game` int(10) DEFAULT '0',
  `win` int(10) DEFAULT '0',
  `point` int(10) DEFAULT '0',
  `burn` int(10) DEFAULT '0',
  `stifle` int(10) DEFAULT '0',
  `touke` int(10) DEFAULT '0',
  `bankrupt` int(10) DEFAULT '0',
  `time` bigint(20) DEFAULT '0',
  `total_win_money` bigint(20) DEFAULT '0',
  `total_win_money_one` bigint(20) DEFAULT '0',
  `total_win_money_two` bigint(20) DEFAULT '0',
  `total_win_money_three` bigint(20) DEFAULT '0',
  `total_win_money_four` bigint(20) DEFAULT '0',
  `max_win_money` bigint(10) DEFAULT '0',
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 guotiepurchase
# ------------------------------------------------------------

CREATE TABLE `guotiepurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `orderid` varchar(128) DEFAULT NULL,
  `third_order_no` varchar(128) DEFAULT NULL,
  `totalfee` bigint(20) DEFAULT NULL,
  `paytype` varchar(32) DEFAULT NULL,
  `title` varchar(64) DEFAULT NULL,
  `suborderstatus` int(11) DEFAULT NULL,
  `suborderstatusstr` varchar(64) DEFAULT NULL,
  `ordercreatetime` varchar(64) DEFAULT NULL,
  `orderupdatetime` varchar(64) DEFAULT NULL,
  `orderfinishtime` varchar(64) DEFAULT NULL,
  `sign` varchar(256) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 guotieuser
# ------------------------------------------------------------

CREATE TABLE `guotieuser` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `refid` varchar(240) NOT NULL,
  `userid` bigint(20) NOT NULL,
  `nickname` varchar(256) NOT NULL,
  `avatarurl` varchar(256) NOT NULL,
  `avatarid` varchar(256) NOT NULL,
  `frontback` varchar(256) NOT NULL,
  `matchid` int(11) NOT NULL,
  `channel` varchar(256) NOT NULL,
  `gameid` int(11) NOT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `refid` (`refid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 haimapurchase
# ------------------------------------------------------------

CREATE TABLE `haimapurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `orderid` varchar(64) NOT NULL,
  `appid` varchar(32) DEFAULT NULL,
  `totalfee` varchar(32) DEFAULT NULL,
  `body` varchar(400) DEFAULT NULL,
  `tradestatus` varchar(4) DEFAULT NULL,
  `notifytime` datetime DEFAULT NULL,
  `userparam` varchar(64) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 honorepurchaseverifiedrecord
# ------------------------------------------------------------

CREATE TABLE `honorepurchaseverifiedrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `verifyid` bigint(20) NOT NULL,
  `verifytype` int(11) DEFAULT NULL,
  `verifydata` text,
  `verifyresult` text,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 honorpurchase
# ------------------------------------------------------------

CREATE TABLE `honorpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `appid` varchar(64) DEFAULT NULL,
  `orderid` varchar(128) DEFAULT NULL,
  `bizorderno` varchar(128) DEFAULT NULL,
  `producttype` int(11) DEFAULT NULL,
  `productid` varchar(128) DEFAULT NULL,
  `productname` varchar(128) DEFAULT NULL,
  `purchasetime` bigint(20) DEFAULT NULL,
  `purchasestate` int(11) DEFAULT NULL,
  `consumptionstate` int(11) DEFAULT NULL,
  `purchasetoken` varchar(256) DEFAULT NULL,
  `currency` varchar(64) DEFAULT NULL,
  `price` varchar(64) DEFAULT NULL,
  `oriorder` varchar(128) DEFAULT NULL,
  `developerpayload` varchar(128) DEFAULT NULL,
  `productprice` varchar(64) DEFAULT NULL,
  `channelcode` varchar(64) DEFAULT NULL,
  `sandboxflag` tinyint(1) DEFAULT NULL,
  `paymoney` varchar(64) DEFAULT NULL,
  `displayprice` varchar(64) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 honorpurchaseverifiedrecord
# ------------------------------------------------------------

CREATE TABLE `honorpurchaseverifiedrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `verifyid` bigint(20) NOT NULL,
  `verifytype` int(11) DEFAULT NULL,
  `verifydata` text,
  `verifyresult` text,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 honorpurchaseverifyinginfo
# ------------------------------------------------------------

CREATE TABLE `honorpurchaseverifyinginfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `verifytype` int(11) DEFAULT NULL,
  `verifydata` text,
  `verifycount` int(11) DEFAULT NULL,
  `verifytime` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 honoruser
# ------------------------------------------------------------

CREATE TABLE `honoruser` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `refid` varchar(240) NOT NULL,
  `openid` varchar(256) NOT NULL,
  `displayname` varchar(256) NOT NULL,
  `accesstoken` varchar(256) NOT NULL,
  `unionid` varchar(256) NOT NULL,
  `age` int(11) NOT NULL,
  `hasrealname` int(11) NOT NULL DEFAULT '0',
  `isadult` int(11) NOT NULL DEFAULT '0',
  `headpictureurl` varchar(256) NOT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `refid` (`refid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 huaweierrorcallback
# ------------------------------------------------------------

CREATE TABLE `huaweierrorcallback` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(128) NOT NULL,
  `thirdpartyorderid` varchar(128) DEFAULT NULL,
  `data` text,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderid` (`orderid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 huaweihmpurchase
# ------------------------------------------------------------

CREATE TABLE `huaweihmpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `purchasetoken` varchar(128) DEFAULT NULL,
  `countrycode` varchar(32) DEFAULT NULL,
  `currency` varchar(64) DEFAULT NULL,
  `developerpayload` varchar(128) DEFAULT NULL,
  `purchasetime` bigint(20) DEFAULT NULL,
  `needfinish` tinyint(1) DEFAULT NULL,
  `finishstatus` tinyint(1) DEFAULT NULL,
  `environment` varchar(32) DEFAULT NULL,
  `signedtime` bigint(20) DEFAULT NULL,
  `producttype` int(11) DEFAULT NULL,
  `purchaseorderid` varchar(128) DEFAULT NULL,
  `applicationid` varchar(128) DEFAULT NULL,
  `price` bigint(20) DEFAULT NULL,
  `productid` varchar(128) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 huaweihmpurchaserecord
# ------------------------------------------------------------

CREATE TABLE `huaweihmpurchaserecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `data` varchar(1024) DEFAULT NULL,
  `sign` varchar(256) DEFAULT NULL,
  `algorithm` varchar(64) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 huaweihmpurchaseverifiedrecord
# ------------------------------------------------------------

CREATE TABLE `huaweihmpurchaseverifiedrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `verifyid` bigint(20) NOT NULL,
  `verifytype` int(11) DEFAULT NULL,
  `verifydata` text,
  `verifyresult` text,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 huaweihmpurchaseverifyinginfo
# ------------------------------------------------------------

CREATE TABLE `huaweihmpurchaseverifyinginfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `verifytype` int(11) DEFAULT NULL,
  `verifydata` text,
  `verifycount` int(11) DEFAULT NULL,
  `verifytime` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 huaweihmuser
# ------------------------------------------------------------

CREATE TABLE `huaweihmuser` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `refid` varchar(240) NOT NULL,
  `gameplayerid` varchar(256) NOT NULL,
  `teamplayerid` varchar(256) NOT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `refid` (`refid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 huaweihmuserbind
# ------------------------------------------------------------

CREATE TABLE `huaweihmuserbind` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `teamplayerid` varchar(240) NOT NULL,
  `userid` bigint(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `password` varchar(240) NOT NULL,
  `status` int(4) NOT NULL COMMENT '0 绑定中 1 绑定信息发生变化 2 已解绑',
  `freshtime` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `teamplayerid` (`teamplayerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 huaweiminiuser
# ------------------------------------------------------------

CREATE TABLE `huaweiminiuser` (
  `unionid` varchar(240) NOT NULL,
  `openid` varchar(240) NOT NULL,
  `scope` varchar(240) NOT NULL,
  `appid` varchar(40) NOT NULL,
  `displayname` varchar(240) DEFAULT NULL,
  `headpictureurl` varchar(1024) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`unionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 huaweipurchase
# ------------------------------------------------------------

CREATE TABLE `huaweipurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `result` char(5) DEFAULT NULL,
  `username` varchar(128) DEFAULT NULL,
  `productname` varchar(100) DEFAULT NULL,
  `paytype` int(11) DEFAULT NULL,
  `amount` char(20) DEFAULT NULL,
  `orderid` varchar(100) DEFAULT NULL,
  `notifytime` varchar(50) DEFAULT NULL,
  `requestid` varchar(50) DEFAULT NULL,
  `bankid` varchar(100) DEFAULT NULL,
  `ordertime` varchar(50) DEFAULT NULL,
  `tradetime` varchar(50) DEFAULT NULL,
  `accessmode` varchar(50) DEFAULT NULL,
  `spending` varchar(50) DEFAULT NULL,
  `extreserved` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 huaweipurchasev2
# ------------------------------------------------------------

CREATE TABLE `huaweipurchasev2` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `applicationid` bigint(20) DEFAULT NULL,
  `autorenewing` tinyint(1) DEFAULT NULL,
  `orderid` varchar(128) DEFAULT NULL,
  `kind` int(11) DEFAULT NULL,
  `packagename` varchar(128) DEFAULT NULL,
  `productid` varchar(128) DEFAULT NULL,
  `productname` varchar(128) DEFAULT NULL,
  `purchasetime` bigint(20) DEFAULT NULL,
  `purchasetimemillis` bigint(20) DEFAULT NULL,
  `purchasestate` int(11) DEFAULT NULL,
  `developerpayload` varchar(128) DEFAULT NULL,
  `developerchallenge` varchar(128) DEFAULT NULL,
  `consumptionstate` int(11) DEFAULT NULL,
  `confirmed` int(11) DEFAULT NULL,
  `purchasetoken` varchar(128) DEFAULT NULL,
  `purchasetype` int(11) DEFAULT NULL,
  `currency` varchar(64) DEFAULT NULL,
  `price` bigint(20) DEFAULT NULL,
  `country` varchar(64) DEFAULT NULL,
  `paytype` varchar(64) DEFAULT NULL,
  `payorderid` varchar(128) DEFAULT NULL,
  `accountflag` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 huaweipurchasev2record
# ------------------------------------------------------------

CREATE TABLE `huaweipurchasev2record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `data` varchar(1024) DEFAULT NULL,
  `sign` varchar(256) DEFAULT NULL,
  `algorithm` varchar(64) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 huaweipurchaseverifiedrecord
# ------------------------------------------------------------

CREATE TABLE `huaweipurchaseverifiedrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `verifyid` bigint(20) NOT NULL,
  `verifytype` int(11) DEFAULT NULL,
  `verifydata` text,
  `verifyresult` text,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 huaweipurchaseverifyinginfo
# ------------------------------------------------------------

CREATE TABLE `huaweipurchaseverifyinginfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `verifytype` int(11) DEFAULT NULL,
  `verifydata` text,
  `verifycount` int(11) DEFAULT NULL,
  `verifytime` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 huaweiuserbind
# ------------------------------------------------------------

CREATE TABLE `huaweiuserbind` (
  `openid` varchar(255) NOT NULL DEFAULT '',
  `appid` varchar(64) NOT NULL DEFAULT '',
  `unionid` varchar(128) DEFAULT NULL,
  `playerid` varchar(128) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`openid`,`appid`),
  KEY `KEY_unionid` (`unionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 i4purchase
# ------------------------------------------------------------

CREATE TABLE `i4purchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `orderid` varchar(50) DEFAULT NULL,
  `billno` varchar(50) DEFAULT NULL,
  `account` varchar(50) DEFAULT NULL,
  `amount` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `appid` int(11) DEFAULT '0',
  `role` int(11) DEFAULT '0',
  `zone` int(11) DEFAULT '0',
  `sign` varchar(2048) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 iapppaypurchase
# ------------------------------------------------------------

CREATE TABLE `iapppaypurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `orderid` varchar(50) DEFAULT NULL,
  `transtype` int(11) DEFAULT '0',
  `transid` varchar(50) DEFAULT NULL,
  `appid` varchar(20) DEFAULT NULL,
  `waresid` int(11) DEFAULT '0',
  `feetype` int(11) DEFAULT '0',
  `money` float DEFAULT '0',
  `currency` varchar(10) DEFAULT NULL,
  `result` int(11) DEFAULT '0',
  `transtime` varchar(20) DEFAULT NULL,
  `cpprivate` varchar(20) DEFAULT NULL,
  `paytype` int(11) DEFAULT '0',
  `sign` varchar(2048) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 idcardcheckrecord
# ------------------------------------------------------------

CREATE TABLE `idcardcheckrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `idnum` varchar(18) DEFAULT NULL,
  `idname` varchar(32) DEFAULT NULL,
  `result` varchar(16) DEFAULT NULL,
  `remark` varchar(64) DEFAULT NULL,
  `orderno` varchar(64) DEFAULT NULL,
  `handletime` varchar(64) DEFAULT NULL,
  `province` varchar(32) DEFAULT NULL,
  `city` varchar(32) DEFAULT NULL,
  `country` varchar(32) DEFAULT NULL,
  `birthday` varchar(32) DEFAULT NULL,
  `age` varchar(8) DEFAULT NULL,
  `gender` varchar(8) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `KEY_idnum_idname` (`idnum`,`idname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 idcardcheckrecordcdp
# ------------------------------------------------------------

CREATE TABLE `idcardcheckrecordcdp` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `idnum` varchar(18) DEFAULT NULL,
  `idname` varchar(32) DEFAULT NULL,
  `result` varchar(16) DEFAULT NULL,
  `message` varchar(64) DEFAULT NULL,
  `seqno` varchar(64) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `KEY_idnum_idname` (`idnum`,`idname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 idcardcheckrecordnppa
# ------------------------------------------------------------

CREATE TABLE `idcardcheckrecordnppa` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `idnum` varchar(18) DEFAULT NULL,
  `idname` varchar(32) DEFAULT NULL,
  `status` varchar(16) DEFAULT NULL,
  `pi` varchar(64) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `KEY_idnum_idname` (`idnum`,`idname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 idcardinfo
# ------------------------------------------------------------

CREATE TABLE `idcardinfo` (
  `idnum` varchar(18) NOT NULL,
  `idname` varchar(32) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `source` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`idnum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 identitycardinfo
# ------------------------------------------------------------

CREATE TABLE `identitycardinfo` (
  `id` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(32) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 idtypeinfo
# ------------------------------------------------------------

CREATE TABLE `idtypeinfo` (
  `idtype` int(11) NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`idtype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 iospurchase
# ------------------------------------------------------------

CREATE TABLE `iospurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `receipt` varchar(7680) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `product_id` varchar(80) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `bid` varchar(80) DEFAULT NULL,
  `bvrs` varchar(80) DEFAULT NULL,
  `transaction_id` varchar(80) DEFAULT NULL,
  `sandbox` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `app_orderid` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 ippool
# ------------------------------------------------------------

CREATE TABLE `ippool` (
  `ip` varchar(128) NOT NULL,
  `integerip` bigint(20) DEFAULT '0',
  `country` varchar(255) DEFAULT NULL,
  `area` varchar(255) DEFAULT NULL,
  `region` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `county` varchar(255) DEFAULT NULL,
  `isp` varchar(255) DEFAULT NULL,
  `countryid` varchar(255) DEFAULT NULL,
  `areaid` varchar(255) DEFAULT NULL,
  `regionid` varchar(255) DEFAULT NULL,
  `cityid` varchar(255) DEFAULT NULL,
  `countyid` varchar(255) DEFAULT NULL,
  `ispid` varchar(255) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  PRIMARY KEY (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 ippoolbak
# ------------------------------------------------------------

CREATE TABLE `ippoolbak` (
  `ip` varchar(128) NOT NULL,
  `country` varchar(255) DEFAULT NULL,
  `area` varchar(255) DEFAULT NULL,
  `region` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `county` varchar(255) DEFAULT NULL,
  `isp` varchar(255) DEFAULT NULL,
  `countryid` int(11) DEFAULT NULL,
  `areaid` int(11) DEFAULT NULL,
  `regionid` int(11) DEFAULT NULL,
  `cityid` int(11) DEFAULT NULL,
  `countyid` int(11) DEFAULT NULL,
  `ispid` int(11) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  PRIMARY KEY (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 jdpaypurchase
# ------------------------------------------------------------

CREATE TABLE `jdpaypurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `tradeno` varchar(64) DEFAULT NULL,
  `outtradeno` varchar(64) DEFAULT NULL,
  `resultcode` varchar(64) DEFAULT NULL,
  `resultdesc` varchar(64) DEFAULT NULL,
  `tradestatus` varchar(64) DEFAULT NULL,
  `tradeamount` varchar(64) DEFAULT NULL,
  `finishdate` varchar(64) DEFAULT NULL,
  `tradetype` varchar(64) DEFAULT NULL,
  `uid` varchar(64) DEFAULT NULL,
  `discountamount` varchar(64) DEFAULT NULL,
  `paytool` varchar(64) DEFAULT NULL,
  `maskcardno` varchar(64) DEFAULT NULL,
  `bankcode` varchar(64) DEFAULT NULL,
  `cardtype` varchar(64) DEFAULT NULL,
  `installmentnum` varchar(64) DEFAULT NULL,
  `banksubmitno` varchar(64) DEFAULT NULL,
  `currency` varchar(64) DEFAULT NULL,
  `extinfo` varchar(64) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `sign` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 jlxmobilefeecharge
# ------------------------------------------------------------

CREATE TABLE `jlxmobilefeecharge` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `merc_order_no` varchar(64) NOT NULL,
  `plat_order_no` varchar(64) DEFAULT NULL,
  `gameorderid` varchar(64) NOT NULL,
  `gameid` int(11) NOT NULL,
  `merc_acc` varchar(64) NOT NULL,
  `product_type` int(11) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `unit` int(11) NOT NULL,
  `num` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `product_discount` decimal(10,6) DEFAULT NULL,
  `merc_status` int(11) NOT NULL,
  `createtime` datetime NOT NULL,
  `updatetime` datetime NOT NULL,
  `notifyinfo` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 jsapipurchase
# ------------------------------------------------------------

CREATE TABLE `jsapipurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `appid` varchar(32) DEFAULT NULL,
  `mch_id` varchar(32) DEFAULT NULL,
  `result_code` varchar(16) DEFAULT NULL,
  `is_subscribe` varchar(8) DEFAULT NULL,
  `trade_type` varchar(16) DEFAULT NULL,
  `bank_type` varchar(16) DEFAULT NULL,
  `total_fee` int(11) DEFAULT NULL,
  `transaction_id` varchar(32) DEFAULT NULL,
  `out_trade_no` varchar(32) DEFAULT NULL,
  `time_end` varchar(14) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 kuaishoupurchase
# ------------------------------------------------------------

CREATE TABLE `kuaishoupurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `appid` varchar(32) DEFAULT NULL,
  `roleid` varchar(32) DEFAULT NULL,
  `serverid` varchar(32) DEFAULT NULL,
  `productid` varchar(32) DEFAULT NULL,
  `money` int(11) DEFAULT NULL,
  `extension` varchar(256) DEFAULT NULL,
  `allintradeno` varchar(32) DEFAULT NULL,
  `data` varchar(256) DEFAULT NULL,
  `sign` varchar(512) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 kuaishouuser
# ------------------------------------------------------------

CREATE TABLE `kuaishouuser` (
  `refid` varchar(240) NOT NULL DEFAULT '',
  `gameid` varchar(240) NOT NULL,
  `username` varchar(240) DEFAULT NULL,
  `userhead` varchar(256) DEFAULT NULL,
  `usergender` varchar(10) DEFAULT NULL,
  `anonymous` tinyint(1) DEFAULT NULL,
  `certificated` tinyint(1) DEFAULT NULL,
  `userbighead` varchar(256) DEFAULT NULL,
  `usercity` varchar(10) DEFAULT NULL,
  `ksopenid` varchar(240) DEFAULT NULL,
  `age` varchar(4) DEFAULT NULL,
  `adult` tinyint(1) DEFAULT NULL,
  `uid` varchar(20) DEFAULT NULL,
  `unionid` varchar(240) DEFAULT NULL,
  `bindchannel` varchar(240) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`refid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 kypurchase
# ------------------------------------------------------------

CREATE TABLE `kypurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` varchar(40) DEFAULT NULL,
  `notifydata` varchar(256) NOT NULL,
  `fee` float DEFAULT NULL,
  `payresult` int(2) DEFAULT NULL,
  `dealseq` varchar(64) DEFAULT NULL,
  `orderid` varchar(32) DEFAULT NULL,
  `subject` varchar(40) DEFAULT NULL,
  `v` varchar(40) DEFAULT NULL,
  `sign` varchar(256) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 lastlogininfo
# ------------------------------------------------------------

CREATE TABLE `lastlogininfo` (
  `userid` bigint(20) NOT NULL,
  `gameid` int(4) DEFAULT NULL,
  `deviceid` varchar(240) DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`userid`),
  KEY `index_name` (`deviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 le8purchase
# ------------------------------------------------------------

CREATE TABLE `le8purchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `orderid` varchar(64) NOT NULL,
  `appid` varchar(32) DEFAULT NULL,
  `totalfee` varchar(32) DEFAULT NULL,
  `body` varchar(400) DEFAULT NULL,
  `tradestatus` varchar(4) DEFAULT NULL,
  `notifytime` datetime DEFAULT NULL,
  `userparam` varchar(64) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 lepaypurchase
# ------------------------------------------------------------

CREATE TABLE `lepaypurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `outtradeorderid` varchar(64) DEFAULT NULL,
  `orderid` varchar(100) DEFAULT NULL,
  `status` int(4) DEFAULT NULL,
  `totalfee` int(4) DEFAULT NULL,
  `extradata` varchar(100) DEFAULT NULL,
  `sign` varchar(512) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 logininfo
# ------------------------------------------------------------

CREATE TABLE `logininfo` (
  `deviceid` varchar(240) NOT NULL,
  `RefID` varchar(240) NOT NULL,
  `LastLogintime` datetime DEFAULT NULL,
  `LastLoginip` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`deviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 loopgamepurchase
# ------------------------------------------------------------

CREATE TABLE `loopgamepurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `cporderid` varchar(64) DEFAULT NULL,
  `orderid` varchar(64) DEFAULT NULL,
  `info` varchar(128) DEFAULT NULL,
  `sign` varchar(32) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 manualpurchase
# ------------------------------------------------------------

CREATE TABLE `manualpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `orderid` varchar(128) NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderid` (`orderid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 matchvspurchase
# ------------------------------------------------------------

CREATE TABLE `matchvspurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `gameid` varchar(10) DEFAULT NULL,
  `openorderid` varchar(32) DEFAULT NULL,
  `openextend` varchar(32) DEFAULT NULL,
  `orderid` varchar(32) DEFAULT NULL,
  `ordertime` varchar(32) DEFAULT NULL,
  `amount` int(11) DEFAULT '0',
  `paytime` varchar(32) DEFAULT NULL,
  `paytype` int(11) DEFAULT '0',
  `cache` varchar(10) DEFAULT NULL,
  `sign` varchar(64) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 meituanminipurchase
# ------------------------------------------------------------

CREATE TABLE `meituanminipurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `mgcorderid` varchar(256) DEFAULT NULL,
  `bizorderid` varchar(256) DEFAULT NULL,
  `mgcid` varchar(20) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `paystatus` varchar(20) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 meituanuser
# ------------------------------------------------------------

CREATE TABLE `meituanuser` (
  `refid` varchar(240) NOT NULL DEFAULT '',
  `mgcunionid` varchar(64) NOT NULL,
  `mgcids` varchar(256) NOT NULL,
  `mgcidsstr` varchar(256) NOT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`refid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 meizupurchase
# ------------------------------------------------------------

CREATE TABLE `meizupurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `orderid` varchar(50) DEFAULT NULL,
  `notifytime` varchar(50) DEFAULT NULL,
  `notifyid` varchar(32) DEFAULT NULL,
  `meizuorderid` bigint(20) DEFAULT '0',
  `appid` bigint(20) DEFAULT '0',
  `uid` bigint(20) DEFAULT '0',
  `partnerid` bigint(20) DEFAULT '0',
  `productid` varchar(64) DEFAULT NULL,
  `productunit` int(11) DEFAULT '0',
  `buyamount` int(11) DEFAULT '0',
  `productperprice` float DEFAULT '0',
  `totalprice` float DEFAULT '0',
  `tradestatus` varchar(10) DEFAULT NULL,
  `ordercreatetime` varchar(50) DEFAULT NULL,
  `paytime` varchar(50) DEFAULT NULL,
  `paytype` int(11) DEFAULT '0',
  `userinfo` varchar(20) DEFAULT NULL,
  `sign` varchar(60) DEFAULT NULL,
  `signtype` varchar(10) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 mmpurchase
# ------------------------------------------------------------

CREATE TABLE `mmpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `transactionid` varchar(64) NOT NULL,
  `tradeid` varchar(64) NOT NULL,
  `ordertype` varchar(32) DEFAULT NULL,
  `orderpayment` varchar(32) DEFAULT NULL,
  `orderid` varchar(64) DEFAULT NULL,
  `channelid` varchar(64) DEFAULT NULL,
  `paycode` varchar(20) DEFAULT NULL,
  `version` varchar(10) DEFAULT NULL,
  `totalprice` varchar(32) DEFAULT NULL,
  `msgtype` varchar(60) DEFAULT NULL,
  `sendaddress_devicetype` varchar(20) DEFAULT NULL,
  `sendaddress_deviceid` varchar(20) DEFAULT NULL,
  `destaddress_devicetype` varchar(20) DEFAULT NULL,
  `destaddress_deviceid` varchar(20) DEFAULT NULL,
  `checkid` int(11) DEFAULT NULL,
  `price` int(10) DEFAULT NULL,
  `actiontime` varchar(14) DEFAULT NULL,
  `actionid` varchar(64) DEFAULT NULL,
  `msisdn` varchar(15) DEFAULT NULL,
  `feemsisdn` varchar(32) DEFAULT NULL,
  `appid` varchar(20) DEFAULT NULL,
  `subsnumb` varchar(4) DEFAULT NULL,
  `subsseq` varchar(4) DEFAULT NULL,
  `md5sign` varchar(32) DEFAULT NULL,
  `provinceid` int(4) DEFAULT NULL,
  `exdata` varchar(64) NOT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 mobilebind
# ------------------------------------------------------------

CREATE TABLE `mobilebind` (
  `userid` bigint(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  PRIMARY KEY (`userid`),
  KEY `AK_KEY_mobile` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 mobilefee
# ------------------------------------------------------------

CREATE TABLE `mobilefee` (
  `gameorderid` varchar(128) NOT NULL,
  `gameid` int(11) NOT NULL,
  `orderid` varchar(128) NOT NULL,
  `userid` bigint(20) NOT NULL,
  `fee` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `feedate` datetime DEFAULT NULL,
  `chargetimes` int(11) NOT NULL,
  `chargelasttime` int(20) NOT NULL,
  PRIMARY KEY (`gameorderid`,`gameid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 mobileidcardcheckrecord
# ------------------------------------------------------------

CREATE TABLE `mobileidcardcheckrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(11) DEFAULT NULL,
  `idnum` varchar(18) DEFAULT NULL,
  `idname` varchar(32) DEFAULT NULL,
  `result` varchar(16) DEFAULT NULL,
  `remark` varchar(64) DEFAULT NULL,
  `orderno` varchar(64) DEFAULT NULL,
  `handletime` varchar(64) DEFAULT NULL,
  `type` varchar(8) DEFAULT NULL,
  `gender` varchar(8) DEFAULT NULL,
  `age` varchar(8) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `KEY_mobile_idnum_idname` (`mobile`,`idnum`,`idname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 mobileidcardcheckrecordcdp
# ------------------------------------------------------------

CREATE TABLE `mobileidcardcheckrecordcdp` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(11) DEFAULT NULL,
  `idnum` varchar(18) DEFAULT NULL,
  `idname` varchar(32) DEFAULT NULL,
  `state` varchar(16) DEFAULT NULL,
  `message` varchar(64) DEFAULT NULL,
  `seqno` varchar(64) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `KEY_mobile_idnum_idname` (`mobile`,`idnum`,`idname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 mobileidcardinfo
# ------------------------------------------------------------

CREATE TABLE `mobileidcardinfo` (
  `mobile` varchar(11) NOT NULL,
  `idnum` varchar(18) DEFAULT NULL,
  `idname` varchar(32) DEFAULT NULL,
  `source` varchar(64) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 mobiletagcheckrecord
# ------------------------------------------------------------

CREATE TABLE `mobiletagcheckrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(11) DEFAULT NULL,
  `tradeno` varchar(64) DEFAULT NULL,
  `status` varchar(16) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `KEY_mobile` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 mobiletaginfo
# ------------------------------------------------------------

CREATE TABLE `mobiletaginfo` (
  `mobile` varchar(11) NOT NULL,
  `tag` int(4) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 nppabind
# ------------------------------------------------------------

CREATE TABLE `nppabind` (
  `userid` bigint(20) NOT NULL,
  `pi` varchar(38) NOT NULL,
  PRIMARY KEY (`userid`),
  KEY `AK_KEY_pi` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 nppaidcardinfo
# ------------------------------------------------------------

CREATE TABLE `nppaidcardinfo` (
  `idnum` varchar(18) NOT NULL,
  `idname` varchar(32) DEFAULT NULL,
  `pi` varchar(38) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`idnum`),
  KEY `KEY_pi` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 nppaidcardqueryinfo
# ------------------------------------------------------------

CREATE TABLE `nppaidcardqueryinfo` (
  `idnum` varchar(18) NOT NULL,
  `idname` varchar(32) NOT NULL,
  `ai` varchar(32) DEFAULT NULL,
  `bizid` varchar(32) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`idnum`,`idname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 numbers
# ------------------------------------------------------------

CREATE TABLE `numbers` (
  `n` int(11) NOT NULL,
  PRIMARY KEY (`n`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 opcoinreviserecord
# ------------------------------------------------------------

CREATE TABLE `opcoinreviserecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticketid` varchar(128) NOT NULL,
  `userid` bigint(20) DEFAULT NULL,
  `delta` int(11) DEFAULT NULL,
  `status` int(4) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticketid` (`ticketid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 oporderchange
# ------------------------------------------------------------

CREATE TABLE `oporderchange` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(64) NOT NULL,
  `userid` bigint(20) NOT NULL,
  `gameid` int(10) NOT NULL,
  `num` int(10) NOT NULL,
  `createtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderid` (`orderid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 oppopurchase
# ------------------------------------------------------------

CREATE TABLE `oppopurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `notifyid` varchar(50) DEFAULT NULL,
  `partnerorder` varchar(100) DEFAULT NULL,
  `productname` varchar(50) DEFAULT NULL,
  `productdesc` varchar(100) DEFAULT NULL,
  `price` int(11) DEFAULT '0',
  `count` int(11) DEFAULT '0',
  `attach` varchar(200) DEFAULT NULL,
  `sign` varchar(2048) DEFAULT NULL,
  `channel` int(4) DEFAULT NULL,
  `adid` varchar(50) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `partnerorder` (`partnerorder`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 oppoqgpurchase
# ------------------------------------------------------------

CREATE TABLE `oppoqgpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `notifyid` varchar(50) DEFAULT NULL,
  `partnerorder` varchar(100) DEFAULT NULL,
  `productname` varchar(50) DEFAULT NULL,
  `productdesc` varchar(100) DEFAULT NULL,
  `price` int(11) DEFAULT '0',
  `count` int(11) DEFAULT '0',
  `attach` varchar(200) DEFAULT NULL,
  `paymentway` varchar(50) DEFAULT NULL,
  `payresult` varchar(50) DEFAULT NULL,
  `sign` varchar(2048) DEFAULT NULL,
  `channel` int(4) DEFAULT NULL,
  `adid` varchar(50) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 paycallbacklog
# ------------------------------------------------------------

CREATE TABLE `paycallbacklog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `url` varchar(1024) DEFAULT NULL,
  `method` varchar(8) NOT NULL,
  `body` varchar(8192) DEFAULT NULL,
  `userid` int(20) NOT NULL,
  `type` varchar(12) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 payinfo
# ------------------------------------------------------------

CREATE TABLE `payinfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `productcode` varchar(56) NOT NULL,
  `gameid` int(11) DEFAULT '0',
  `paytype` int(11) NOT NULL,
  `payid` varchar(128) NOT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `productcode_gameid_paytype_payid` (`productcode`,`gameid`,`paytype`,`payid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 pkfoxpurchase
# ------------------------------------------------------------

CREATE TABLE `pkfoxpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `orderid` varchar(64) DEFAULT NULL,
  `transactionno` varchar(64) DEFAULT NULL,
  `statuscode` varchar(10) DEFAULT NULL,
  `productid` varchar(64) DEFAULT NULL,
  `orderprice` varchar(32) DEFAULT NULL,
  `packageid` varchar(32) DEFAULT NULL,
  `productname` varchar(128) DEFAULT NULL,
  `extparam` varchar(32) DEFAULT NULL,
  `uid` varchar(32) DEFAULT NULL,
  `sign` varchar(64) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 pppurchase
# ------------------------------------------------------------

CREATE TABLE `pppurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `merId` varchar(32) DEFAULT NULL,
  `merOrderNo` varchar(64) NOT NULL,
  `OrderNo` varchar(64) NOT NULL,
  `payAmt` int(11) DEFAULT NULL,
  `transTime` varchar(32) DEFAULT NULL,
  `bankName` varchar(64) DEFAULT NULL,
  `orderStatus` int(11) DEFAULT NULL,
  `errorCode` varchar(64) DEFAULT NULL,
  `errorMsg` varchar(64) DEFAULT NULL,
  `merUserId` bigint(20) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 purchaseblacklist
# ------------------------------------------------------------

CREATE TABLE `purchaseblacklist` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` int(4) DEFAULT NULL,
  `content` varchar(120) DEFAULT NULL,
  `gameid` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `content` (`content`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 purchasenotifiedrecord
# ------------------------------------------------------------

CREATE TABLE `purchasenotifiedrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(128) DEFAULT NULL,
  `notifyurl` varchar(1024) DEFAULT NULL,
  `notifydata` text,
  `responsedata` text,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 purchasenotifyinginfo
# ------------------------------------------------------------

CREATE TABLE `purchasenotifyinginfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(128) DEFAULT NULL,
  `notifyurl` varchar(1024) DEFAULT NULL,
  `notifydata` text,
  `notifycount` int(11) DEFAULT NULL,
  `notifytime` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderid` (`orderid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 purchaseorderinfo
# ------------------------------------------------------------

CREATE TABLE `purchaseorderinfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(128) NOT NULL,
  `gameorderid` varchar(128) NOT NULL,
  `productcode` varchar(56) NOT NULL,
  `producttype` int(11) DEFAULT NULL,
  `productcost` int(11) DEFAULT NULL,
  `productname` varchar(256) DEFAULT NULL,
  `productdesc` varchar(256) DEFAULT NULL,
  `userid` bigint(20) DEFAULT NULL,
  `gameid` int(4) DEFAULT NULL,
  `method` int(4) DEFAULT NULL,
  `extra` text,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderid` (`orderid`),
  KEY `gameorderid` (`gameorderid`),
  KEY `productcode` (`productcode`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 purchaseverifiedrecord
# ------------------------------------------------------------

CREATE TABLE `purchaseverifiedrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `verifyid` bigint(20) DEFAULT NULL,
  `orderid` varchar(128) DEFAULT NULL,
  `callbackinfo` text,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 purchaseverifyinginfo
# ------------------------------------------------------------

CREATE TABLE `purchaseverifyinginfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(128) DEFAULT NULL,
  `productid` varchar(64) DEFAULT NULL,
  `method` int(11) DEFAULT NULL,
  `callbackinfo` text,
  `verifycount` int(11) DEFAULT NULL,
  `verifytime` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 pywpurchase
# ------------------------------------------------------------

CREATE TABLE `pywpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `ver` varchar(10) DEFAULT NULL,
  `tid` varchar(16) DEFAULT NULL,
  `sign` varchar(64) DEFAULT NULL,
  `gamekey` varchar(20) DEFAULT NULL,
  `channel` varchar(10) DEFAULT NULL,
  `cporderid` varchar(64) DEFAULT NULL,
  `chorderid` varchar(64) DEFAULT NULL,
  `amount` float DEFAULT '0',
  `cpparam` varchar(128) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 qifanpurchase
# ------------------------------------------------------------

CREATE TABLE `qifanpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `appid` varchar(32) DEFAULT NULL,
  `qfuserid` varchar(32) DEFAULT NULL,
  `qforder` varchar(64) DEFAULT NULL,
  `price` varchar(32) DEFAULT NULL,
  `paytype` varchar(32) DEFAULT NULL,
  `state` varchar(32) DEFAULT NULL,
  `paycode` varchar(32) DEFAULT NULL,
  `time` varchar(32) DEFAULT NULL,
  `gameorder` varchar(64) DEFAULT NULL,
  `sign` varchar(32) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 qihoopurchase
# ------------------------------------------------------------

CREATE TABLE `qihoopurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_order_id` varchar(128) NOT NULL,
  `order_id` varchar(256) NOT NULL,
  `app_uid` bigint(20) NOT NULL,
  `user_id` varchar(128) NOT NULL,
  `product_id` varchar(80) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 qqgamepurchase
# ------------------------------------------------------------

CREATE TABLE `qqgamepurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `balance` int(11) DEFAULT NULL,
  `genbalance` int(11) DEFAULT NULL,
  `billno` varchar(32) DEFAULT NULL,
  `usedgenamt` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 qqgameuser
# ------------------------------------------------------------

CREATE TABLE `qqgameuser` (
  `refid` varchar(240) NOT NULL DEFAULT '',
  `openid` varchar(240) DEFAULT NULL,
  `nickname` varchar(240) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `figureurl` varchar(1024) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`refid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 qquser
# ------------------------------------------------------------

CREATE TABLE `qquser` (
  `refid` varchar(240) NOT NULL DEFAULT '',
  `unionid` varchar(240) NOT NULL,
  `nickname` varchar(240) DEFAULT NULL,
  `gender` int(4) DEFAULT NULL,
  `province` varchar(240) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `headimgurl` varchar(1024) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`refid`),
  UNIQUE KEY `unionid` (`unionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 qquserbind
# ------------------------------------------------------------

CREATE TABLE `qquserbind` (
  `openid` varchar(128) NOT NULL DEFAULT '',
  `appid` varchar(64) NOT NULL DEFAULT '',
  `unionid` varchar(128) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`openid`,`appid`),
  KEY `KEY_unionid` (`unionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 qqwalletpurchase
# ------------------------------------------------------------

CREATE TABLE `qqwalletpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `spbillno` varchar(32) DEFAULT NULL,
  `ver` varchar(8) DEFAULT NULL,
  `charset` varchar(8) DEFAULT NULL,
  `payresult` int(11) DEFAULT '0',
  `payinfo` varchar(64) DEFAULT '0',
  `transactionid` varchar(28) DEFAULT '0',
  `totalfee` int(11) DEFAULT '0',
  `feetype` int(11) DEFAULT '0',
  `bargainorid` varchar(10) DEFAULT NULL,
  `attach` varchar(255) DEFAULT NULL,
  `sign` varchar(32) DEFAULT NULL,
  `banktype` varchar(16) DEFAULT NULL,
  `bankbillno` varchar(32) DEFAULT NULL,
  `timeend` varchar(14) DEFAULT NULL,
  `purchasealias` varchar(64) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 realnamebind
# ------------------------------------------------------------

CREATE TABLE `realnamebind` (
  `userid` bigint(20) NOT NULL,
  `id` varchar(20) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `type` int(4) DEFAULT '1',
  `status` int(4) DEFAULT NULL,
  `reason` int(4) DEFAULT '0',
  `times` int(4) DEFAULT NULL,
  `freshtime` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`userid`),
  KEY `index_id` (`id`),
  KEY `index_status` (`status`),
  KEY `index_freshtime` (`freshtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 rolepower
# ------------------------------------------------------------

CREATE TABLE `rolepower` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role` int(11) NOT NULL,
  `controller` varchar(240) NOT NULL,
  `action` varchar(240) NOT NULL,
  PRIMARY KEY (`role`,`controller`,`action`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 sensitiveword
# ------------------------------------------------------------

CREATE TABLE `sensitiveword` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) DEFAULT NULL,
  `type` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 taobaopurchase
# ------------------------------------------------------------

CREATE TABLE `taobaopurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `cooporderno` varchar(64) DEFAULT NULL,
  `tborderno` varchar(64) DEFAULT NULL,
  `gameid` int(11) DEFAULT NULL,
  `appkey` varchar(256) DEFAULT NULL,
  `method` varchar(256) DEFAULT NULL,
  `sign` varchar(64) DEFAULT NULL,
  `timestamp` varchar(32) DEFAULT NULL,
  `cardnum` varchar(32) DEFAULT NULL,
  `tbordersnap` varchar(512) DEFAULT NULL,
  `cardid` varchar(64) DEFAULT NULL,
  `coopid` varchar(32) DEFAULT NULL,
  `notifyurl` varchar(256) DEFAULT NULL,
  `amount` varchar(32) DEFAULT NULL,
  `section1` varchar(128) DEFAULT NULL,
  `section2` varchar(128) DEFAULT NULL,
  `version` varchar(16) DEFAULT NULL,
  `customer` varchar(256) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tborderno` (`tborderno`),
  KEY `cooporderno` (`cooporderno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 taobaouser
# ------------------------------------------------------------

CREATE TABLE `taobaouser` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `refid` varchar(240) NOT NULL,
  `accesstoken` varchar(256) NOT NULL,
  `appkey` varchar(256) NOT NULL,
  `miniappid` varchar(256) NOT NULL,
  `openid` varchar(256) NOT NULL,
  `requestid` varchar(256) NOT NULL,
  `sourceip` varchar(128) NOT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `refid` (`refid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 textdetectinfo
# ------------------------------------------------------------

CREATE TABLE `textdetectinfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `text` varchar(128) DEFAULT NULL,
  `tag` int(11) DEFAULT NULL,
  `words` varchar(128) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQUE_text` (`text`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 textdetectrecord
# ------------------------------------------------------------

CREATE TABLE `textdetectrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `text` varchar(128) DEFAULT NULL,
  `response` text,
  `gameid` int(4) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `KEY_userid` (`userid`),
  KEY `KEY_text` (`text`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 totalpurchase
# ------------------------------------------------------------

CREATE TABLE `totalpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `orderid` varchar(256) NOT NULL,
  `productid` varchar(64) DEFAULT NULL,
  `originalprice` int(11) DEFAULT NULL,
  `currentprice` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `beizhu` varchar(256) DEFAULT NULL,
  `method` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `gameid` int(11) DEFAULT NULL,
  `notifystatus` int(11) DEFAULT '0',
  `gameorderid` varchar(256) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `AK_KEY_userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 totaltransfer
# ------------------------------------------------------------

CREATE TABLE `totaltransfer` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `orderid` varchar(256) DEFAULT '',
  `transferprice` int(11) DEFAULT '0',
  `method` int(11) DEFAULT '0',
  `status` int(4) DEFAULT '0',
  `gameorderid` varchar(256) DEFAULT '0',
  `gameid` int(11) DEFAULT '0',
  `notifystatus` int(4) DEFAULT '0',
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `KEY_orderid` (`orderid`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 transfercode
# ------------------------------------------------------------

CREATE TABLE `transfercode` (
  `transfercode` varchar(128) NOT NULL,
  `userid` bigint(20) NOT NULL,
  `method` int(4) DEFAULT '0',
  `transferprice` int(11) DEFAULT '0',
  `status` int(4) DEFAULT '0',
  `expiretime` datetime NOT NULL,
  `gameorderid` varchar(256) DEFAULT '0',
  `gameid` int(11) DEFAULT '0',
  `createtime` datetime NOT NULL,
  PRIMARY KEY (`transfercode`),
  KEY `index_expiretime` (`expiretime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 trialuser
# ------------------------------------------------------------

CREATE TABLE `trialuser` (
  `refid` varchar(240) NOT NULL,
  `trialid` varchar(240) NOT NULL,
  `gameid` int(4) NOT NULL,
  `createtime` datetime NOT NULL,
  PRIMARY KEY (`trialid`,`gameid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 ucpurchase
# ------------------------------------------------------------

CREATE TABLE `ucpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `ver` varchar(10) DEFAULT NULL,
  `gameid` varchar(20) DEFAULT NULL,
  `tradeid` varchar(32) DEFAULT NULL,
  `tradetime` varchar(20) DEFAULT NULL,
  `orderid` varchar(32) DEFAULT NULL,
  `amount` varchar(32) DEFAULT NULL,
  `paytype` varchar(10) DEFAULT NULL,
  `attachinfo` varchar(32) DEFAULT NULL,
  `orderstatus` varchar(4) DEFAULT NULL,
  `faileddesc` varchar(32) DEFAULT NULL,
  `sign` varchar(64) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 unionpaypurchase
# ------------------------------------------------------------

CREATE TABLE `unionpaypurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `merorderid` varchar(128) NOT NULL,
  `mid` varchar(32) NOT NULL,
  `tid` varchar(16) NOT NULL,
  `couponamount` int(11) DEFAULT NULL,
  `buyerpayamount` int(11) DEFAULT NULL,
  `totalamount` int(11) DEFAULT NULL,
  `invoiceamount` int(11) DEFAULT NULL,
  `paytime` varchar(32) DEFAULT NULL,
  `seqid` varchar(32) DEFAULT NULL,
  `settledate` varchar(32) DEFAULT NULL,
  `status` varchar(32) DEFAULT NULL,
  `targetorderid` varchar(128) DEFAULT NULL,
  `targetsys` varchar(128) DEFAULT NULL,
  `callbackinfo` text,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `merorderid` (`merorderid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 unipaypurchase
# ------------------------------------------------------------

CREATE TABLE `unipaypurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `orderid` varchar(24) NOT NULL,
  `ordertime` varchar(14) DEFAULT NULL,
  `cpid` varchar(40) DEFAULT NULL,
  `appid` varchar(40) DEFAULT NULL,
  `fid` varchar(20) DEFAULT NULL,
  `consumecode` varchar(40) DEFAULT NULL,
  `payfee` int(11) DEFAULT NULL,
  `paytype` int(11) DEFAULT NULL,
  `hret` int(11) DEFAULT NULL,
  `status` varchar(32) DEFAULT NULL,
  `signmsg` varchar(64) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 user
# ------------------------------------------------------------

CREATE TABLE `user` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `IDType` int(4) NOT NULL,
  `RefID` varchar(240) NOT NULL,
  `DeviceID` varchar(240) NOT NULL,
  `Token` varchar(240) DEFAULT NULL,
  `Status` int(4) NOT NULL,
  `Nick` varchar(240) DEFAULT NULL,
  `Guest` tinyint(2) NOT NULL DEFAULT '0' COMMENT '褰.间负澶т?绛.?1?舵.娓稿.',
  `Face` int(4) DEFAULT NULL,
  `Avatar` varchar(240) DEFAULT '',
  `Gender` tinyint(2) DEFAULT NULL,
  `Coin` bigint(20) DEFAULT '0',
  `CreateIP` varchar(20) DEFAULT NULL,
  `CreateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`IDType`,`RefID`),
  KEY `AK_Key_User_1` (`ID`) USING BTREE,
  KEY `AK_KEY_DeviceID` (`DeviceID`),
  KEY `AK_KEY_CreateIP` (`CreateIP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 userconsume
# ------------------------------------------------------------

CREATE TABLE `userconsume` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `consumetype` int(4) DEFAULT NULL,
  `isactive` int(4) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `KEY_consumetype` (`consumetype`),
  KEY `KEY_isactive` (`isactive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 userinfochange
# ------------------------------------------------------------

CREATE TABLE `userinfochange` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `type` int(4) DEFAULT NULL,
  `oldrecord` varchar(240) DEFAULT NULL,
  `newrecord` varchar(240) DEFAULT NULL,
  `gameid` int(4) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 userinfochangetypeinfo
# ------------------------------------------------------------

CREATE TABLE `userinfochangetypeinfo` (
  `type` int(11) NOT NULL,
  `desc` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 userlockrecord
# ------------------------------------------------------------

CREATE TABLE `userlockrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `ticketid` varchar(128) NOT NULL,
  `caseid` varchar(128) NOT NULL,
  `locktype` int(4) DEFAULT NULL,
  `violation` varchar(256) DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `gameid` int(4) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticketid` (`ticketid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 userpunishrecord
# ------------------------------------------------------------

CREATE TABLE `userpunishrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `ticketid` varchar(128) NOT NULL,
  `caseid` varchar(128) NOT NULL,
  `gmid` varchar(64) NOT NULL,
  `gmtype` int(4) DEFAULT NULL,
  `punishtype` int(4) DEFAULT NULL,
  `duration` bigint(20) DEFAULT NULL,
  `violation` varchar(256) DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `gameid` int(4) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 userrestrictions
# ------------------------------------------------------------

CREATE TABLE `userrestrictions` (
  `userid` bigint(20) NOT NULL,
  `deviceid` varchar(240) NOT NULL,
  PRIMARY KEY (`userid`,`deviceid`),
  KEY `deviceid` (`deviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 userrole
# ------------------------------------------------------------

CREATE TABLE `userrole` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `game` varchar(240) NOT NULL,
  `username` varchar(240) NOT NULL,
  `roletype` int(11) NOT NULL,
  PRIMARY KEY (`game`,`username`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 uservalidlockinfo
# ------------------------------------------------------------

CREATE TABLE `uservalidlockinfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `caseid` varchar(128) NOT NULL,
  `locktype` int(4) DEFAULT NULL,
  `violation` varchar(256) DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 uservalidpunishinfo
# ------------------------------------------------------------

CREATE TABLE `uservalidpunishinfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `punishtype` int(4) DEFAULT NULL,
  `caseid` varchar(128) DEFAULT NULL,
  `duration` bigint(20) DEFAULT NULL,
  `violation` varchar(256) DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 uucunpurchase
# ------------------------------------------------------------

CREATE TABLE `uucunpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `appkey` varchar(32) DEFAULT NULL,
  `txnseq` varchar(32) DEFAULT NULL,
  `orderid` varchar(30) DEFAULT NULL,
  `rspcode` varchar(6) DEFAULT NULL,
  `txntime` varchar(4) DEFAULT NULL,
  `actualtxnamt` int(11) DEFAULT '0',
  `timestamp` varchar(17) DEFAULT NULL,
  `signmsg` varchar(64) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 vivopurchase
# ------------------------------------------------------------

CREATE TABLE `vivopurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `orderid` varchar(50) DEFAULT NULL,
  `respcode` varchar(10) DEFAULT NULL,
  `respmsg` varchar(50) DEFAULT NULL,
  `signmethod` varchar(10) DEFAULT NULL,
  `signature` varchar(64) DEFAULT NULL,
  `storeid` varchar(30) DEFAULT NULL,
  `vivoorder` varchar(64) DEFAULT NULL,
  `orderamount` varchar(20) DEFAULT NULL,
  `channel` varchar(64) DEFAULT NULL,
  `channelfee` varchar(20) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 vivopurchasev3
# ------------------------------------------------------------

CREATE TABLE `vivopurchasev3` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `cpordernumber` varchar(50) DEFAULT NULL,
  `respcode` varchar(10) DEFAULT NULL,
  `respmsg` varchar(50) DEFAULT NULL,
  `signmethod` varchar(10) DEFAULT NULL,
  `signature` varchar(64) DEFAULT NULL,
  `tradetype` varchar(10) DEFAULT NULL,
  `tradestatus` varchar(10) DEFAULT NULL,
  `cpid` varchar(30) DEFAULT NULL,
  `appid` varchar(30) DEFAULT NULL,
  `ordernumber` varchar(64) DEFAULT NULL,
  `orderamount` varchar(20) DEFAULT NULL,
  `extInfo` varchar(64) DEFAULT NULL,
  `paytime` varchar(20) DEFAULT NULL,
  `uid` varchar(20) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 vivouser
# ------------------------------------------------------------

CREATE TABLE `vivouser` (
  `refid` varchar(240) NOT NULL,
  `openid` varchar(240) NOT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`refid`),
  UNIQUE KEY `openid` (`openid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 webcastloginlicence
# ------------------------------------------------------------

CREATE TABLE `webcastloginlicence` (
  `authcode` varchar(240) NOT NULL DEFAULT '',
  `deviceid` varchar(240) DEFAULT NULL,
  `userid` bigint(20) DEFAULT NULL,
  `status` int(4) DEFAULT NULL,
  `authority` varchar(32) DEFAULT 'login',
  `freshtime` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`authcode`),
  KEY `KEY_userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 webcastpurchase
# ------------------------------------------------------------

CREATE TABLE `webcastpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `orderid` varchar(128) NOT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderid` (`orderid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 webcastpurchaselicence
# ------------------------------------------------------------

CREATE TABLE `webcastpurchaselicence` (
  `userid` bigint(20) NOT NULL DEFAULT '0',
  `gameid` int(11) NOT NULL DEFAULT '0',
  `gamedailylimit` int(11) DEFAULT NULL,
  `gamemonthlylimit` int(11) DEFAULT NULL,
  `platdailylimit` int(11) DEFAULT NULL,
  `platmonthlylimit` int(11) DEFAULT NULL,
  `paypin` varchar(10) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`userid`,`gameid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 wechatattentionbinduser
# ------------------------------------------------------------

CREATE TABLE `wechatattentionbinduser` (
  `id` bigint(20) NOT NULL,
  `userid` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 wechatattentionrecord
# ------------------------------------------------------------

CREATE TABLE `wechatattentionrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fromusername` varchar(512) NOT NULL,
  `duoleid` int(11) NOT NULL,
  `gameid` int(11) NOT NULL,
  `xml` varchar(1024) NOT NULL,
  `beizhu` varchar(512) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 wechatattentionuser
# ------------------------------------------------------------

CREATE TABLE `wechatattentionuser` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `unionid` varchar(240) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 wechatminipaycallbacklog
# ------------------------------------------------------------

CREATE TABLE `wechatminipaycallbacklog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `request` text,
  `response` text,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 wechatminipurchase
# ------------------------------------------------------------

CREATE TABLE `wechatminipurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `openid` varchar(64) DEFAULT NULL,
  `appid` varchar(32) DEFAULT NULL,
  `offerid` varchar(32) DEFAULT NULL,
  `ts` int(11) DEFAULT NULL,
  `zoneid` int(11) DEFAULT NULL,
  `pf` varchar(32) DEFAULT NULL,
  `amt` int(11) DEFAULT NULL,
  `billno` varchar(128) NOT NULL,
  `sig` varchar(256) DEFAULT NULL,
  `accesstoken` varchar(256) DEFAULT NULL,
  `errcode` int(11) DEFAULT NULL,
  `errmsg` varchar(256) DEFAULT NULL,
  `balance` int(11) DEFAULT NULL,
  `usedgenamt` int(11) DEFAULT NULL,
  `env` int(11) DEFAULT '0',
  `signature` varchar(256) DEFAULT '',
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 wechatpurchase
# ------------------------------------------------------------

CREATE TABLE `wechatpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `appid` varchar(32) DEFAULT NULL,
  `attach` varchar(32) DEFAULT NULL,
  `mch_id` varchar(32) DEFAULT NULL,
  `nonce_str` varchar(32) DEFAULT NULL,
  `openid` varchar(64) DEFAULT NULL,
  `result_code` varchar(16) DEFAULT NULL,
  `return_code` varchar(16) DEFAULT NULL,
  `sign` varchar(128) DEFAULT NULL,
  `is_subscribe` varchar(8) DEFAULT NULL,
  `trade_type` varchar(16) DEFAULT NULL,
  `bank_type` varchar(16) DEFAULT NULL,
  `cash_fee` int(11) DEFAULT NULL,
  `fee_type` varchar(32) DEFAULT NULL,
  `total_fee` int(11) DEFAULT NULL,
  `transaction_id` varchar(32) DEFAULT NULL,
  `out_trade_no` varchar(32) DEFAULT NULL,
  `time_end` varchar(14) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 wechatpurchasev2
# ------------------------------------------------------------

CREATE TABLE `wechatpurchasev2` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `appid` varchar(32) DEFAULT NULL,
  `mchid` varchar(32) DEFAULT NULL,
  `outtradeno` varchar(32) DEFAULT NULL,
  `transactionid` varchar(32) DEFAULT NULL,
  `tradetype` varchar(16) DEFAULT NULL,
  `tradestate` varchar(32) DEFAULT NULL,
  `tradestatedesc` varchar(256) DEFAULT NULL,
  `banktype` varchar(16) DEFAULT NULL,
  `attach` varchar(128) DEFAULT NULL,
  `successtime` varchar(64) DEFAULT NULL,
  `openid` varchar(128) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `payertotal` int(11) DEFAULT NULL,
  `currency` varchar(16) DEFAULT NULL,
  `payercurrency` varchar(16) DEFAULT NULL,
  `sceneinfo` varchar(256) DEFAULT NULL,
  `promotiondetail` varchar(256) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 wechattransfer
# ------------------------------------------------------------

CREATE TABLE `wechattransfer` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `partner_trade_no` varchar(256) NOT NULL,
  `openid` varchar(128) DEFAULT '',
  `amount` int(11) DEFAULT '0',
  `return_code` varchar(16) DEFAULT '',
  `return_msg` varchar(128) DEFAULT '',
  `mch_appid` varchar(32) DEFAULT '',
  `mchid` varchar(32) DEFAULT '',
  `device_info` varchar(32) DEFAULT '',
  `nonce_str` varchar(32) DEFAULT '',
  `result_code` varchar(16) DEFAULT '',
  `err_code` varchar(32) DEFAULT '',
  `err_code_des` varchar(128) DEFAULT '',
  `payment_no` varchar(32) DEFAULT '',
  `payment_time` varchar(128) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `KEY_partner_trade_no` (`partner_trade_no`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 wechatuser
# ------------------------------------------------------------

CREATE TABLE `wechatuser` (
  `refid` varchar(240) DEFAULT NULL,
  `unionid` varchar(240) NOT NULL,
  `nickname` varchar(240) DEFAULT NULL,
  `gender` int(4) DEFAULT '0',
  `province` varchar(240) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `language` varchar(20) DEFAULT NULL,
  `headimgurl` varchar(1024) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`unionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 wechatuserbind
# ------------------------------------------------------------

CREATE TABLE `wechatuserbind` (
  `openid` varchar(128) NOT NULL DEFAULT '',
  `appid` varchar(64) NOT NULL DEFAULT '',
  `unionid` varchar(128) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`openid`,`appid`),
  KEY `KEY_unionid` (`unionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 wechatusermigrationrecord
# ------------------------------------------------------------

CREATE TABLE `wechatusermigrationrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fromunionid` varchar(240) NOT NULL,
  `tounionid` varchar(240) NOT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQUE_fromunionid` (`fromunionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 wifikeypurchase
# ------------------------------------------------------------

CREATE TABLE `wifikeypurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `orderid` varchar(64) DEFAULT NULL,
  `orderno` varchar(64) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `payamount` varchar(10) DEFAULT NULL,
  `goodsinfo` varchar(32) DEFAULT NULL,
  `md5sign` varchar(32) DEFAULT NULL,
  `extinfo` varchar(128) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 wxpublicpurchase
# ------------------------------------------------------------

CREATE TABLE `wxpublicpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) DEFAULT NULL,
  `appid` varchar(32) DEFAULT NULL,
  `attach` varchar(32) DEFAULT '',
  `mchid` varchar(32) DEFAULT NULL,
  `noncestr` varchar(32) DEFAULT '',
  `openid` varchar(32) DEFAULT '',
  `resultcode` varchar(16) DEFAULT NULL,
  `returncode` varchar(32) DEFAULT '',
  `sign` varchar(128) DEFAULT '',
  `issubscribe` varchar(8) DEFAULT NULL,
  `tradetype` varchar(16) DEFAULT NULL,
  `banktype` varchar(16) DEFAULT NULL,
  `cashfee` int(11) DEFAULT '0',
  `feetype` varchar(32) DEFAULT '',
  `totalfee` int(11) DEFAULT NULL,
  `transactionid` varchar(32) DEFAULT NULL,
  `outtradeno` varchar(32) DEFAULT NULL,
  `timeend` varchar(14) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 xgamepurchase
# ------------------------------------------------------------

CREATE TABLE `xgamepurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `orderid` varchar(128) NOT NULL,
  `status` varchar(64) NOT NULL,
  `extend` varchar(128) NOT NULL,
  `msg` varchar(64) DEFAULT NULL,
  `timestamp` varchar(20) DEFAULT NULL,
  `sign` varchar(256) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 xgameuser
# ------------------------------------------------------------

CREATE TABLE `xgameuser` (
  `uid` varchar(240) NOT NULL,
  `nickname` varchar(240) DEFAULT NULL,
  `gender` int(4) DEFAULT '0',
  `headimgurl` varchar(1024) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 xiaomipurchase
# ------------------------------------------------------------

CREATE TABLE `xiaomipurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `cporderid` varchar(128) NOT NULL,
  `orderid` varchar(128) NOT NULL,
  `orderstatus` varchar(64) NOT NULL,
  `payfee` int(11) DEFAULT NULL,
  `productcode` varchar(64) DEFAULT NULL,
  `productcount` int(11) DEFAULT NULL,
  `paytime` varchar(64) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 xypurchase
# ------------------------------------------------------------

CREATE TABLE `xypurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `orderid` varchar(64) DEFAULT NULL,
  `uid` varchar(64) DEFAULT NULL,
  `serverid` varchar(20) DEFAULT NULL,
  `amount` varchar(32) DEFAULT NULL,
  `extra` varchar(64) NOT NULL,
  `ts` datetime DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 yybpurchase
# ------------------------------------------------------------

CREATE TABLE `yybpurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `openid` varchar(64) DEFAULT NULL,
  `appid` varchar(64) DEFAULT NULL,
  `ts` varchar(20) DEFAULT NULL,
  `payitem` varchar(128) DEFAULT NULL,
  `token` varchar(64) DEFAULT NULL,
  `billno` varchar(64) DEFAULT NULL,
  `cftid` varchar(64) DEFAULT NULL,
  `channelid` varchar(64) DEFAULT NULL,
  `version` varchar(32) DEFAULT NULL,
  `zoneid` varchar(4) DEFAULT NULL,
  `providetype` varchar(4) DEFAULT NULL,
  `amt` varchar(10) DEFAULT NULL,
  `payamtcoins` varchar(10) DEFAULT NULL,
  `pubacctpayamtcoins` varchar(10) DEFAULT NULL,
  `appmeta` varchar(128) DEFAULT NULL,
  `clientver` varchar(10) DEFAULT NULL,
  `sig` varchar(64) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 yybuser
# ------------------------------------------------------------

CREATE TABLE `yybuser` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `refid` varchar(240) NOT NULL,
  `openid` varchar(256) NOT NULL,
  `accesstoken` varchar(256) NOT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `refid` (`refid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# 转储表 zhuoyipurchase
# ------------------------------------------------------------

CREATE TABLE `zhuoyipurchase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `rechargeid` varchar(64) DEFAULT NULL,
  `appid` varchar(32) DEFAULT NULL,
  `uin` int(11) DEFAULT NULL,
  `urechargeid` varchar(64) DEFAULT NULL,
  `extra` varchar(64) DEFAULT NULL,
  `rechargemoney` decimal(4,2) DEFAULT '0.00',
  `rechargegoldcount` varchar(10) DEFAULT NULL,
  `paystatus` int(4) DEFAULT '0',
  `zycreatetime` int(11) DEFAULT '0',
  `sign` varchar(32) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




--
-- Dumping routines (PROCEDURE) for database 'duole'
--
DELIMITER ;;

# Dump of PROCEDURE UpdateCoin
# ------------------------------------------------------------

/*!50003 SET SESSION SQL_MODE="NO_ENGINE_SUBSTITUTION"*/;;
/*!50003 CREATE*/ /*!50020 DEFINER=`duoletest`@`%`*/ /*!50003 PROCEDURE `UpdateCoin`(IN `userid` bigint , IN `coinchg` int, OUT `result` int)
BEGIN
    DECLARE coinnum int ;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET result = -1;
    set coinnum = 0 ;
    set result = 0 ;
    START TRANSACTION;
    
    select coin into coinnum from user where id = userid for update;
    if coinnum < 0 then
        set result = -2;
    else
        if coinnum + coinchg >= 0 then
            update user set coin = coin + coinchg where id = userid;
        else
            set result = -3;
        end if;
    end if;
    if result = 0 then 
        COMMIT;
    else
        ROLLBACK;
    end if;
END */;;

/*!50003 SET SESSION SQL_MODE=@OLD_SQL_MODE */;;
DELIMITER ;

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
